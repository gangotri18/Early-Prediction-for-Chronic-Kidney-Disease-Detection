from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load the trained CKD model
model = pickle.load(open('CKD.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('home.html')  # Landing page

@app.route('/Prediction', methods=['GET', 'POST'])
def prediction():
    return render_template('indexnew.html')  # Form for user input

@app.route('/Home', methods=['GET', 'POST'])
def my_home():
    return render_template('home.html')  # Optional second route to home

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract input values from form and convert to float
        input_features = [float(x) for x in request.form.values()]
        features_value = [np.array(input_features)]

        # List of feature names used in training
        features_name = ['blood_urea', 'blood_glucose_random', 'anemia',
                         'coronary_artery_disease', 'pus_cell',
                         'red_blood_cells', 'diabetesmellitus', 'pedal_edema']

        # Create a DataFrame using input
        df = pd.DataFrame(features_value, columns=features_name)

        # Make prediction
        output = model.predict(df)[0]  # Get first prediction

        # Convert prediction to readable result
        if output == 1:
            result = "High chance of Chronic Kidney Disease (CKD)"
        else:
            result = "Low chance of Chronic Kidney Disease (CKD)"

        return render_template('result.html', prediction_text=result)

    except Exception as e:
        return f"Error occurred: {e}"

if __name__ == "__main__":
    app.run(debug=True)
